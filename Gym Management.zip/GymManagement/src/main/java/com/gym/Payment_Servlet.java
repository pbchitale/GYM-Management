package com.gym;

import java.io.IOException;
import java.sql.*;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/payment")
public class Payment_Servlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
    	
    	
        String fullname = request.getParameter("fullname");
        String email = request.getParameter("email");
        int membershipId = Integer.parseInt(request.getParameter("membership_id"));
        String paymentMethod = request.getParameter("payment_method");

        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;

        try {
            Class.forName("oracle.jdbc.driver.OracleDriver");
            conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","sql141");

            // Get membership details
            ps = conn.prepareStatement("SELECT membership_type, duration_months, price FROM Membership WHERE membership_id=?");
            ps.setInt(1, membershipId);
            rs = ps.executeQuery();

            String membershipType = "";
            int duration = 0;
            double price = 0;
            if(rs.next()){
                membershipType = rs.getString("membership_type");
                duration = rs.getInt("duration_months");
                price = rs.getDouble("price");
            }
            rs.close(); ps.close();

            // Insert into GymMembers with default password
            ps = conn.prepareStatement("INSERT INTO GymMembers (fullname, email, password, payment_method, duration_months) VALUES (?,?,?,?,?)");
            ps.setString(1, fullname);
            ps.setString(2, email);
            ps.setString(3, "default123");
            ps.setString(4, paymentMethod);
            ps.setInt(5, duration);

            int rows = ps.executeUpdate();
            ps.close(); conn.close();

            if(rows>0){
                request.setAttribute("fullname", fullname);
                request.setAttribute("email", email);
                request.setAttribute("membershipType", membershipType);
                request.setAttribute("duration", duration);
                request.setAttribute("price", price);
                request.setAttribute("paymentMethod", paymentMethod);
                request.getRequestDispatcher("payment_success.jsp").forward(request, response);
            } else {
                response.getWriter().println("<h3>Payment Failed. Try again.</h3>");
            }

        } catch(Exception e){
            e.printStackTrace();
            response.getWriter().println("<h3>Error: "+e.getMessage()+"</h3>");
        } finally {
            try{ if(ps!=null) ps.close(); if(conn!=null) conn.close(); } catch(Exception ex){}
        }
    }
}
