package com.gym;

import java.io.IOException;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/Pa")
public class PaymentServlet extends HttpServlet {
	
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        System.out.println("PaymentServlet");
        String fullname = request.getParameter("fullname");
        String email = request.getParameter("email");
        String membership = request.getParameter("membership_type");
        double amount = Double.parseDouble(request.getParameter("amount_paid"));

        Connection conn = null;
        PreparedStatement ps = null;

        try {
            // Load Oracle JDBC driver
            Class.forName("oracle.jdbc.driver.OracleDriver");

            // Connect DB (change username/password if needed)
            conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "sql141");

            // Insert into GymMembers
            String sql = "INSERT INTO GymMembers (id, fullname, email, membership_type, amount_paid) VALUES (gymmembers_seq.NEXTVAL, ?, ?, ?, ?)";
            ps = conn.prepareStatement(sql);
            ps.setString(1, fullname);
            ps.setString(2, email);
            ps.setString(3, membership);
            ps.setDouble(4, amount);
            
            int rows = ps.executeUpdate();

            if (rows > 0) {
                // Redirect to show members page
                response.sendRedirect("showMember.jsp");
            } else {
                response.getWriter().println("Payment Failed. Try Again.");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.getWriter().println("Error: " + e.getMessage());
        } finally {
            try { if (ps != null) ps.close(); if (conn != null) conn.close(); } catch (Exception ex) {}
        }
    }
}
