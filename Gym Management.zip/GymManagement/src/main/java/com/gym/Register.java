package com.gym;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/Register")
public class Register extends HttpServlet {
    private static final long serialVersionUID = 1L;

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String fullname = request.getParameter("fullname");
        String email = request.getParameter("email");
        String password = request.getParameter("password");
        String confirmPassword = request.getParameter("confirmPassword");

        // Check if passwords match
        if (!password.equals(confirmPassword)) {
            request.setAttribute("errorMessage", "Passwords do not match!");
            request.getRequestDispatcher("registration.jsp").forward(request, response);
            return;
        }

        Connection con = null;
        PreparedStatement ps = null;

        try {
            // Load Oracle JDBC Driver
            Class.forName("oracle.jdbc.OracleDriver");

            // Connect to database
            con = DriverManager.getConnection(
                    "jdbc:oracle:thin:@//localhost:1521/XE", "system", "sql141");

            // Insert query
            String sql = "INSERT INTO GymUsers(fullname, email, password, role) VALUES(?,?,?,?)";
            ps = con.prepareStatement(sql);
            ps.setString(1, fullname);
            ps.setString(2, email);
            ps.setString(3, password);
            ps.setString(4, "user"); // default role

            // Execute insertion
            ps.executeUpdate();

            // Redirect to login page after successful registration
            response.sendRedirect("login.jsp");

        } catch (Exception e) {
            e.printStackTrace(); // Print error to server logs
            request.setAttribute("errorMessage", "Registration failed! Email may already exist.");
            request.getRequestDispatcher("registration.jsp").forward(request, response);

        } finally {
            try {
                if (ps != null) ps.close();
                if (con != null) con.close();
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        }
    }
}
